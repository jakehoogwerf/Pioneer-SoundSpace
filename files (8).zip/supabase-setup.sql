-- Run this once in Supabase: Dashboard -> SQL Editor -> New query -> paste -> Run

create table if not exists class_playlists (
  class_name text primary key,
  songs jsonb not null default '[]'::jsonb,
  updated_at timestamptz not null default now()
);

create table if not exists class_playlist_history (
  id serial primary key,
  class_name text not null,
  songs jsonb not null,
  changed_at timestamptz not null default now()
);

create index if not exists class_playlist_history_class_idx
  on class_playlist_history (class_name, changed_at);
