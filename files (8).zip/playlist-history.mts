import type { Config, Context } from '@netlify/functions'
import { supabaseDb } from '../../db/supabase.js'
import { classPlaylistHistory, classPlaylists } from '../../db/schema.js'
import { eq, desc } from 'drizzle-orm'

const ALLOWED_CLASSES = new Set([
  'kangaroos',
  'bilby',
  'swans',
  'numbats',
  'bobtails',
  'karak',
  'wombats',
  'PE',
])

export default async (req: Request, context: Context) => {
  const className = context.params.class
  if (!className || !ALLOWED_CLASSES.has(className)) {
    return new Response('Invalid class', { status: 400 })
  }

  // View the last 20 saved versions of this class's playlist, newest first.
  if (req.method === 'GET') {
    const rows = await supabaseDb
      .select()
      .from(classPlaylistHistory)
      .where(eq(classPlaylistHistory.className, className))
      .orderBy(desc(classPlaylistHistory.changedAt))
      .limit(20)
    return Response.json(rows)
  }

  // Restore a specific history snapshot back into the live playlist.
  // Body: { "historyId": 123 } - the id from a row returned by GET above.
  if (req.method === 'POST') {
    let body: { historyId?: number }
    try {
      body = await req.json()
    } catch {
      return new Response('Invalid JSON', { status: 400 })
    }
    if (typeof body.historyId !== 'number') {
      return new Response('Missing historyId', { status: 400 })
    }

    const rows = await supabaseDb
      .select()
      .from(classPlaylistHistory)
      .where(eq(classPlaylistHistory.id, body.historyId))
      .limit(1)

    const snapshot = rows[0]
    if (!snapshot || snapshot.className !== className) {
      return new Response('Snapshot not found', { status: 404 })
    }

    await supabaseDb
      .insert(classPlaylists)
      .values({ className, songs: snapshot.songs, updatedAt: new Date() })
      .onConflictDoUpdate({
        target: classPlaylists.className,
        set: { songs: snapshot.songs, updatedAt: new Date() },
      })

    return Response.json({ restored: true, songs: snapshot.songs })
  }

  return new Response('Method not allowed', { status: 405 })
}

export const config: Config = {
  path: '/api/playlist-history/:class',
  method: ['GET', 'POST'],
}
